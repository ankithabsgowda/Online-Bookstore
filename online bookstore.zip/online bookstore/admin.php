<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="Admin")
{
	header("location:index.php");
}   

?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   
</head>
    <body>
        <div id="headerAdmin">
            <h3><center><br> Welcome Admin </h3><br><a style="color:white;float:right;margin-right:100px;" href="logout.php">Logut(<?php echo $_SESSION['user']; ?>)</a>
             
        
                 
                 <?php
         
            
           
              if(isset($_GET['prod_title']))
            {
                $product_title=$_GET['prod_title'];
             $get_prod="select * from products where prod_title='$product_title'";
             $run_products= mysqli_query($conn, $get_prod);
             while($row_prod=mysqli_fetch_array($run_products))
             {
                 $pro_id=$row_prod['prod_id'];
                 $pro_title=$row_prod['prod_title'];
                 $pro_author=$row_prod['prod_author'];
                 $pro_img=$row_prod['prod_img1'];
                 $pro_desc=$row_prod['prod_desc'];
               
              echo"
                 <div id='singleprod'>
                 <a href='user.php'>BACK</a>
                  <h4>$pro_title</h4>
                      <h3>Author: $pro_author</h3>
                      <p>$pro_desc</p></br>
                  <img src=images/$pro_img width='160' height='160'/> </br></br>
                       
                      <button  position:center>Download</button>
                      
                </div>
                    
                      ";
             }
            }
             ?>
        </div>
             
        </div> 
        
        <div id="navigAdmin">
            <ul>
                <li><a href="admin.php">Home</a></li> 
               
            </ul>
        </div> 
        
         <div class="siderightadmin">
             
             <h3>Manage Content</h3>
             <h2><a href="admin.php?insert_prod">Add new Book</a></h2>
             <h2> <a href="admin.php?view_prod">View Book</a></h2>
             <h2> <a href="admin.php?view_cust">View Customers Requests</a></h2>
              <h2><a href="admin.php?cust_contri">Customer Contributions</a></h2>
             
        </div> 
        
     
        
       <div>
            <img class="imageside" src="images/tbw2.jpg">
        </div>
        
       
         <div class="mainB" >
          <?php
         
            
            
               if(isset($_GET['insert_prod']))
               {
                   include("insert_prod.php");
               }
               else if(isset($_GET['view_prod']))
               {
                   include("view_prod.php");
               }
                else if(isset($_GET['view_cust']))
               {
                   include("view_cust.php");
               }
               else if(isset($_GET['cust_contri']))
               {
                   include("cust_contri.php");
               }
			   else 
			   {
				   include("view_prod.php");
			   }
               ?>
             
             </div>
         
         <div id="footerA">
             &copy: 2019 Bookstream.com.  All Rights Reserved.
             </div> 
         
        
         
</body>
<script>
    
    function randomImage() {
        var img = document.querySelector('.imageside');
    
    var images = ['aatm.jpg','tbw2.jpg', 'rdpd2.jpg','et2.jpg','gg2.jpg','psm2.jpg','ltm2.jpg','tgd2.jpg', 'pt2.jpg','ta.jpg','sao1.jpg'];
    var num = Math.floor(Math.random() * images.length);
    
    var newimg = images[num];
    img.src = 'images/' + newimg;
    }
    
    setInterval(randomImage, 3000);
    
</script>    
</html> 
         
         
