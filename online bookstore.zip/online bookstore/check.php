<?php
session_start();
$ck=$_SESSION['logged'];
if($ck!="User" || $ck!="Admin")
{
header("location:index.php");
}
else
{
}
?>