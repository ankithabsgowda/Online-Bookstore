<?php
if(isset($_POST['submit']))
{
 $cuname=$_POST['cname'];   
  $email=$_POST['cemail'];   
   $book=$_POST['cbook'];   
    $auth=$_POST['cabook'];   
    $file=fopen("custrequest/req.txt","a+") or die("file not open");
    $s=$cuname.",".$email.",".$book.",".$auth."\n";
    fputs($file,$s)or die("dint write");
    echo "<script>alert('your request has been sent..');</script>";
        fclose($file);header("Location:user.php");    
        
	
			  
        }
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   
</head>
    <body>
        <div id="header">
            <h1><center><b> BookStream </h1>
             <p><center>Where Books meet people </p>
             
            
        </div>
             
      
        
        <div id="navig">
            
            <ul>
                <li><a href="user.php">Home</a></li> 
                <li><a href="disc.php">Disclaimer</a></li> 
                 <li><a href="upload.php">Donate Pdf</a></li> 
                 <li><a href="contact.php">Contact Us</a></li> 
            </ul>
        </div> 
        
         <div class="sideright">
            <h2> Recent Uploads </h2>
             <P>Looking for Alaska- John Green</P> 
             <P>Gone Girl -Gillian Flynn</P> 
             <P>Till the Last Breath-Durjoy Datta</P> 
             <P>After all this Time-Nikitha Singh</P> 
        </div> 
        <div class="sideright">
            <h2> Popular Uploads </h2>
             <P>Paper Towns- John Green</P> 
             <P>Rich Dad Poor Dad-Robert T Kiyosaki</P> 
             <P>If its Not Forever-Durjoy Datta</P> 
             <P>Girl in Room 105-Chetan Bhagat</P> 
        </div> 
        
        <div>
            <img class="imageside" src=images/aatm.jpg >
        </div>
        
       
         <div class="main">
               <form method="post" action="contact.php" enctype="multipart/form-data">
      
         
            <table width="900" allign="center">
                <tr>
                <h4> Contact us </h4>
            </tr>
            <tr>
                <td><h2>Name:</h2></td>
                <td><input type="text" name="cname"/></td>
            </tr>
            <tr>
                <td><h2>Email:</h2></td>
                <td><input type="text" name="cemail"/></td>
            </tr>
            <tr>
                <td><h2>Requested Book name</h2></td>
                <td><input type="text" name="cbook"/></td>
            </tr>
             <tr>
                <td><h2>Author of the book</h2></td>
                <td><input type="text" name="cabook"/></td>
            </tr>
            
           
            <tr>
                <td><h2>Submit</h2></td>
                <td><input type="submit" name="submit"/></td>
            </tr>
            
                </table
     
        </form>
         
            
             </div>
         
         <div id="footer">
             &copy: 2019 Bookstream.com.  All Rights Reserved.
             </div> 
         
        
         
</body>
<script>
    
    function randomImage() {
        var img = document.querySelector('.imageside');
    
    var images = ['aatm.jpg', 'gg2.jpg', 'ltm2.jpg','tgd2.jpg', 'pt2.jpg','taimj.jpg','sao1.jpg'];
    var num = Math.floor(Math.random() * images.length);
    
    var newimg = images[num];
    img.src = 'images/' + newimg;
    }
    
    setInterval(randomImage, 4000);
    
</script>    
</html>
        



       