<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="Admin")
{
	header("location:index.php");
}  
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   <style>
   .link { color: yellow; } /* CSS link color (red) */
.link:hover { color: #fff; } /* CSS link hover (green) */
   </style>
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   <body>
        <div id="mainA">
            
            <center><font size="6px" color='purple'><b><u>Books donated</u> </font></center>
    <table style="width:100%" id="customerContrib">
        <tr>
            <td><h3>Book name</h5></td>
            <td><h3>File Size</h5></td>
            <td><h3>View</h5></td>
           
        </tr>
             
      
         
            <?php


                if($handle = opendir("customer_docs"))
                {
                    while(($entry = readdir($handle)) !== false)
                    {
                        if($entry != "." && $entry != "..")
                        {                         
                            echo "<tr><td>$entry<td>";
                           $size = ceil(filesize("customer_docs/" . $entry) / 1024);
                            echo "<font color='red'>".$size .".KB<td></font>"; 
                              echo "<a style='color:red' class='link' href='customer_docs/$entry' target='_blank'>View</a></td></tr>";
                                                       
                          
                            
                           
                        }
                    }
                }
            ?>   

    </table>
        </div>
    </body>
</html>

