<?php
error_reporting(E_ALL ^ E_NOTICE);
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   
</head>
    <body>
        <div id="header">
            <h1><center> BookStream </h1>
             <p><center> Where books meet people </p>
             
            
        </div>
             
      
        
        <div id="navig">
            
            <ul>
                <li><a href="user.php">Home</a></li> 
                <li><a href="disc.php">Disclaimer</a></li> 
                 <li><a href="upload.php">Donate Pdf</a></li> 
                 <li><a href="contact.php">Contact Us</a></li> 
            </ul>
        </div> 
        
         <div class="sideright">
            <h2> Recent Uploads </h2>
             <P>Looking for Alaska- John Green</P> 
             <P>Gone Girl -Gillian Flynn</P> 
             <P>Till the Last Breath-Durjoy Datta</P> 
             <P>After all this Time-Nikitha Singh</P> 
        </div> 
        <div class="sideright">
            <h2> Popular Uploads </h2>
             <P>Paper Towns- John Green</P> 
             <P>Rich Dad Poor Dad-Robert T Kiyosaki</P> 
             <P>If its Not Forever-Durjoy Datta</P> 
             <P>Girl in Room 105-Chetan Bhagat</P> 
        </div> 
        
        <div>
            <img class="imageside" src="images/tbw2.jpg">
        </div>
        
       
         <div class="main">
          
             <h2> We do not host any files on its servers.All contents are provided by non affiliated third parties</h2>
             <h2> So we dont accept responsiblity for content hosted by the third party websites</h2>
             <h2> For any copyright issues,you should contact the hosters files sites itself</h2>
             <h2> if you think any of the content of this site infringes any intellectual property law and you hold the</h2>
             <h2>copyright of the content please report it to admin@bookstream.com the content will be removed immediately</h2>
             
            
            
             </div>
         
         <div id="footer">
             &copy: 2019 Bookstream.com.  All Rights Reserved.
             </div> 
         
        
         
</body>
<script>
    
    function randomImage() {
        var img = document.querySelector('.imageside');
    
    var images = ['aatm.jpg','tbw2.jpg', 'rdpd2.jpg','et2.jpg','gg2.jpg','psm2.jpg','ltm2.jpg','tgd2.jpg', 'pt2.jpg','ta.jpg','sao1.jpg'];
    var num = Math.floor(Math.random() * images.length);
    
    var newimg = images[num];
    img.src = 'images/' + newimg;
    }
    
    setInterval(randomImage, 3000);
    
</script>    
</html>
