<?php


if(isset($_GET['tit']))
{
$tit=$_GET['tit'];
$reading = fopen("Download/".$tit.".txt", 'r');
while (!feof($reading)) {
  $line = fgets($reading);
}
fclose($reading);

$line=$line+1;
$file2 = fopen("Download/".$tit.".txt", 'w');
fputs($file2,$line);
fclose($file2);

header('Content-type: application/pdf');
header('Content-Disposition: attachment; filename=bfiles/'.$tit.'.pdf');
readfile($tit.'.pdf');

}
?>
