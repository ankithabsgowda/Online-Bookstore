<!DOCTYPE html>
<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck=="Admin")
{
	header("location:admin.php");
}   
if($ck=="User")
{
	header("location:user.php");
} 
$msg="";
if(isset($_POST['submit']))
{
    $type=$_POST['type'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    if($type=="Admin")
    {$file = fopen('DB/Admin.txt', 'r');}
    else if($type=="User")
    {$file = fopen('DB/User.txt', 'r');}
    $good=false;

    while(!feof($file))
    {
    $line = fgets($file);
    list($name,	$user, $pass) = explode(';', $line);
    if(trim($user) == $username && trim($pass) == $password)
    {
        $good=true;
        break;
    }
    }
    fclose($file);
    if(!$good)
    {
     $msg="Invalid Credential..";
    }
    else
    {

    	if($type=="Admin" )
    	{
			$_SESSION['user']=$username;
			$_SESSION['logged']="Admin";
        header("Location:admin.php");
    	}
    	else if($type=="User")
    	{
		    $_SESSION['user']=$name;
			$_SESSION['logged']="User";
         header("Location:user.php");
			
    	}
    }
    
}
?>

     
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login Form</title>
         <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'links.php' ; ?>
        </head>
    <body>
	<style>
.but{
  display: inline-block;
  padding: 10px 20px;
  font-size: 20px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #234;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.but:hover {background-color: #a34;}

.button:active {
  background-color: #234;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
           
                    
        <div class="container center-div shadow" style="width:20%;height:70%"> 
            <div class="heading text-center text-uppercase text-danger ">
                Login </div>
				<center>
            <div class="container row">
                 <div class="admin-form">
                     <form  method="POST" action="index.php" >
                         <div class="form-group"><br>
                         <label>User Type</label>
                <select name="type" class="form-control" required>
                <option value="">select user role</option>
                <option value="Admin">Admin</option>
                <option value="User">User</option>
            </select>
            </div>
                         <div class="form-group">
                             <label>Email ID </label>
                             <input type="email" name="username" placeholder="" class="form-control" required/>
                                 
                               </div>  
                         <div class="form-group">
                             <label>Password</label>
                             <input type="password" name="password" value="" style="margin-bottom:-10px;" class="form-control" required>
							
                               </div> <br/><br>
<input type="submit"  class="but" name="submit" style="margin-top:-25px;margin-bottom:-20px;" value="  Login   " ><br><br>
<a href ="register.php"> Sign Up </a>						
<font color="red"><?php echo "<BR>".$msg;?></font>
                     </form>
                </div>
        </div>
        </div>
         </body>
</html>
