<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="Admin")
{
	header("location:index.php");
}  
?>



<?php


if(isset($_POST['submit']))
{
    $pauth=$_POST['pro_author'];
    $ptit=$_POST['pro_title'];
    $pdesc=$_POST['pro_desc'];
	
	$tt = $ptit.".jpg";
    $ttt = $ptit.".pdf";
	$tttt = $ptit.".txt";
	
		if(($_FILES["pro_img"]["type"]!="image/jpg" && $_FILES["pro_img"]["type"]!="image/jpeg" && $_FILES["pro_img"]["type"]!="image/png" && $_FILES["pro_img"]["type"]!="image/JPG" && $_FILES["pro_img"]["type"]!="image/JPEG")  || $_FILES["pro_file"]["type"]!="application/pdf")
		{
		echo "<script>
			alert('Image Format is not JPG /JPEG OR File is Not Pdf');
			window.location.href='admin.php?insert_prod';
		      </script>";		
		exit;
		}
		else
		{
		move_uploaded_file($_FILES["pro_img"]["tmp_name"],"images/".$tt);
		chmod("images/".$tt,0777);
		move_uploaded_file($_FILES["pro_file"]["tmp_name"],"bfiles/".$ttt);
		chmod("bfiles/".$ttt,0777);
		
		$file1 = fopen('Files/'.$tttt, 'w');
		fputs($file1,$pauth.";".$ptit."\n".$pdesc."\n");
		fclose($file1);
		$file2 = fopen('Rate/'.$tttt, 'w');
		fclose($file2);
		$file3 = fopen('Download/'.$tttt, 'w');
		fputs($file3,"0");
		fclose($file3);
		echo "<script>alert('New Book Added Successfully..');</script>";
		header("Location:admin.php?view_prod");   
		}
}

?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   

    <body>
        <form method="post" action="insert_prod.php" enctype="multipart/form-data">
        <div class="mainB">
         
            <table width="900" allign="center" >
                <tr>
                <h5><font color='black' size='6px'> <b><u><center>Insert a book </b></u></center></font></h5>
            </tr>
            <tr>
                <td><h3>Book name:</h5></td>
                <td><input type="text" name="pro_title"/></td>
            </tr>
            <tr>
                <td><h3>Book author:</h5></td>
                <td><input type="text" name="pro_author"/></td>
            </tr>
            <tr>
                <td><h3>Insert cover photo:</h5></td>
                <td><input style="width:250px;height:50px;" type="file" name="pro_img"/></td>
            </tr>
            <tr>
                <td><h3>Description:</h5></td>
                <td><textarea name="pro_desc" cols="40" rows="20"></textarea></td>
            </tr>
            
            
            
             <tr>
                <td><h3>Insert pdf:</h5></td>
                <td><input style="width:250px;height:50px;" type="file" name="pro_file"/></td>
            </tr>
            <tr>
                <td><h3>Submit</h5></td>
                <td><input type="submit" style="width:250px;height:50px;" value="Add Book" name="submit"/></td>
            </tr>
            
            </table>
        </div>
        </form>
            </body>
        
        </html>
        