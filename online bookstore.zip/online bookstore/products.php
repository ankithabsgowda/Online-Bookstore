<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="Admin" && $ck!="User")
{
	header("location:index.php");
}  
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   
</head>
    <body>
        <div id="header">
            <h1><center><b> BookStream </h1>
             <P><center>Where Books meet people </P>
             
            
        </div>
             
      
          
      
        
        <div id="navig">
            
            <ul>
                <li><a href="user.php">Home</a></li> 
                <li><a href="disc.php">Disclaimer</a></li> 
                 <li><a href="upload.php">Donate Pdf</a></li> 
                 <li><a href="contact.php">Contact Us</a></li> 
            </ul>
        </div> 
        
         <div class="sideright">
            <h2> Recent Uploads </h2>
             <P>Looking for Alaska- John Green</P> 
             <P>Gone Girl -Gillian Flynn</P> 
             <P>Till the Last Breath-Durjoy Datta</P> 
             <P>After all this Time-Nikitha Singh</P> 
        </div> 
        <div class="sideright">
            <h2> Popular Uploads </h2>
             <P>Paper Towns- John Green</P> 
             <P>Rich Dad Poor Dad-Robert T Kiyosaki</P> 
             <P>If its Not Forever-Durjoy Datta</P> 
             <P>Girl in Room 105-Chetan Bhagat</P> 
        </div> 
        
        <div>
            <img class="imageside" src=images/pt2.jpg>
        </div>
        
       
         <div class="mainA">
          
             <?php
            
            if(isset($_GET['prod_id']))
            {
				$product_id=$_GET['prod_id'];
					$i=0;
					$pro_des="";
					$file = fopen("Files/".$product_id.".txt", 'r');
					while(!feof($file))
					{
						$line = fgets($file);
						if($i==0)
						{
							list($pro_auth,	$pro_tit) = explode(';', $line);
						}
						else
						{
							$pro_des=$pro_des.$line."\n";
						}
						$i=$i+1;
								
					}
					fclose($file);	
					$dwn=0;
					$file2 = fopen("Download/".$product_id.".txt", 'r');
					$dwn=fgets($file2);
					fclose($file2);
			?>
						
              
                 <div id='singleprod'>
                 
				 <button onclick="goBack()">Go Back</button>

				<script>
				function goBack() 
				{
					window.history.back();
				}
				</script>
				
                  <h4><?php echo $pro_tit; ?></h4>
                      <h3>Author: <?php echo  $pro_auth; ?></h3>
                      <p style="font-family: monospace;line-height: 30px;font-size:17px;text-align-last: justify"><?php echo $pro_des; ?></p></br>
                  <center><img src='images/<?php echo $pro_tit.".jpg"; ?>'  width='200' height='240'/> 
				  <fieldset class="rating">
				  <input type="hidden" value="<?php echo $pro_tit; ?>" name="title" id="title" />
				  <input type="hidden" value="<?php echo $_SESSION['user']; ?>" name="usr" id="usr" />
    <legend>Please rate:</legend>
    <input type="radio" id="star5" name="rating" value="5" onclick="Rate(this.value)" /><label for="star5" title="Rocks!">5 stars</label>
    <input type="radio" id="star4" name="rating" value="4" onclick="Rate(this.value)"/><label for="star4" title="Pretty good">4 stars</label>
    <input type="radio" id="star3" name="rating" value="3" onclick="Rate(this.value)"/><label for="star3" title="Meh">3 stars</label>
    <input type="radio" id="star2" name="rating" value="2" onclick="Rate(this.value)"/><label for="star2" title="Kinda bad">2 stars</label>
    <input type="radio" id="star1" name="rating" value="1" onclick="Rate(this.value)"/><label for="star1" title="Sucks big time">1 star</label>
</fieldset>
				  </br>
                   Total Downloads : <?php echo $dwn; ?>  <br>   
                  <a  onclick="Downy()" ><button style="width:200px;height:50px;"> Download </button> </a>
				  
                      
                </div>
				
				
  
                    
            <?php
             }
        
          ?>
             </div>
         
         <div id="footer">
             &copy: 2019 Bookstream.com.  All Rights Reserved.
             </div> 
    </body>
     <script>
    function Rate(str)
	{
		var usr=document.getElementById("usr").value;
		var tit=document.getElementById("title").value;
		
		window.location.href = "rating.php?usr="+usr+"&tit="+tit+"&rate="+str;
	}
	function Downy()
	{
		
		var tit=document.getElementById("title").value;
		window.location.href = "download.php?tit="+tit;
	}
	
    function randomImage() {
        var img = document.querySelector('.imageside');
    
    var images = ['aatm.jpg','tbw2.jpg', 'rdpd2.jpg','et2.jpg','gg2.jpg','psm2.jpg','ltm2.jpg','tgd2.jpg', 'pt2.jpg','ta.jpg','sao1.jpg'];
    var num = Math.floor(Math.random() * images.length);
    
    var newimg = images[num];
    img.src = 'images/' + newimg;
    }
    
    setInterval(randomImage, 3000);
    
</script>    

</html>
        
     