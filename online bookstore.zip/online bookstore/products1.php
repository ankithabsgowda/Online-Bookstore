<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="Admin" && $ck!="User")
{
	header("location:index.php");
}  
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   
</head>
    <body>
        <div id="header">
            <h1>BookStream </h1>
             <h2>Where Books meet people </h2>
             
            
        </div>
             
      
          
      
        
        <div id="navig">
            
            <ul>
                <li><a href="user.php">Home</a></li> 
                <li><a href="disc.php">Disclaimer</a></li> 
                 <li><a href="upload.php">Donate Pdf</a></li> 
                 <li><a href="contact.php">Contact Us</a></li> 
            </ul>
        </div> 
        
         <div class="sideright">
            <h2> Recent Uploads </h2>
             <P>Looking for Alaska- John Green</P> 
             <P>Gone Girl -Gillian Flynn</P> 
             <P>Till the Last Breath-Durjoy Datta</P> 
             <P>After all this Time-Nikitha Singh</P> 
        </div> 
        <div class="sideright">
            <h2> Popular Uploads </h2>
             <P>Paper Towns- John Green</P> 
             <P>Rich Dad Poor Dad-Robert T Kiyosaki</P> 
             <P>If its Not Forever-Durjoy Datta</P> 
             <P>Girl in Room 105-Chetan Bhagat</P> 
        </div> 
        
        <div>
            <img class="imageside" src=images/pt2.jpg>
        </div>
        
       
         <div class="main">
          
             <?php
            
            if(isset($_GET['prod_id']))
            {
				$product_id=$_GET['prod_id'];
					$i=0;
					$pro_des="";
					$file = fopen("Files/".$product_id.".txt", 'r');
					while(!feof($file))
					{
						$line = fgets($file);
						if($i==0)
						{
							list($pro_auth,	$pro_tit) = explode(';', $line);
						}
						else
						{
							$pro_des=$pro_des.$line."\n";
						}
						$i=$i+1;
								
					}
					fclose($file);	
			?>
						
              
                 <div id='singleprod'>
                 
				 <button onclick="goBack()">Go Back</button>

				<script>
				function goBack() 
				{
					window.history.back();
				}
				</script>
				
                  <h4><?php echo $pro_tit; ?></h4>
                      <h3>Author: <?php echo  $pro_auth; ?></h3>
                      <p> <?php echo $pro_des; ?></p></br>
                  <img src='images/<?php echo $pro_tit.".jpg"; ?>' width='200' height='250'/> </br></br>
                       
                  <a  href="bfiles/<?php echo $pro_tit.".pdf" ?>" target='_blank'><button  position:center> Download </button> </a>
                      
                </div>
                    
            <?php
             }
        
          ?>
             </div>
         
         <div id="footer">
             &copy: 2019 Bookstream.com.  All Rights Reserved.
             </div> 
    </body>
     <script>
    
    function randomImage() {
        var img = document.querySelector('.imageside');
    
    var images = ['aatm.jpg','tbw2.jpg', 'rdpd2.jpg','et2.jpg','gg2.jpg','psm2.jpg','ltm2.jpg','tgd2.jpg', 'pt2.jpg','ta.jpg','sao1.jpg'];
    var num = Math.floor(Math.random() * images.length);
    
    var newimg = images[num];
    img.src = 'images/' + newimg;
    }
    
    setInterval(randomImage, 3000);
    
</script>    

</html>
        
     