<?php

if(isset($_GET['usr']))
{
$usr=$_GET['usr'];
$tit=$_GET['tit'];
$rate=$_GET['rate'];

$reading = fopen("Rate/".$tit.".txt", 'r');
$writing = fopen("Rate/".$tit.".temp", 'w');

$replaced = false;

while (!feof($reading)) {
  $line = fgets($reading);
  list($usr1,$rate1) = explode(';', $line);
  if (stristr($usr1,$usr)) {
    $line = $usr.";".$rate."\n";
    $replaced = true;
  }
  fputs($writing, $line);
}
fclose($reading); 
fclose($writing);
// might as well not overwrite the file if we didn't replace anything
if ($replaced) 
{
  rename("Rate/".$tit.".temp", "Rate/".$tit.".txt");
}
 else 
 {
  unlink("Rate/".$tit.".temp");
  $file1 = fopen("Rate/".$tit.".txt", 'a');
  fputs($file1,$usr.";".$rate."\n");
  fclose($file1);
}
header("Location:user.php");   
}


?>