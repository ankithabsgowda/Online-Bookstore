
<!DOCTYPE html>
<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck=="Admin")
{
	header("location:admin.php");
}   
if($ck=="User")
{
	header("location:user.php");
} 

if(isset($_POST['submit']))
{
    $name=$_POST['fname'];
    $username=$_POST['username'];
    $password=$_POST['password'];
   
    $file1 = fopen('DB/User.txt', 'a');
	fputs($file1,$name.";".$username.";".$password."\n");
    fclose($file1);
	echo "<script>alert('Registered Successfully..');</script>";
	header("Location:index.php");   
    
}
?>

     
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login Form</title>
         <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'links.php' ; ?>
        </head>
    <body>
	<style>
.but{
  display: inline-block;
  padding: 10px 20px;
  font-size: 20px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #234;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.but:hover {background-color: #a34;}

.button:active {
  background-color: #234;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
</style>
           
                    
        <div class="container center-div shadow" style="width:20%;height:70%"> 
            <div class="heading text-center text-uppercase text-danger ">
                New User </div>
				<center>
            <div class="container row">
			 <div class="admin-form">
                     <form  method="POST" action="register.php" >
                 <div class="form-group"><br><br>
                             <label>Name &nbsp;&nbsp;&nbsp;</label>
                             <input type="text" name="fname" placeholder="" class="form-control" required/>
                                 
                               </div>  
                         <div class="form-group">
                             <label>Email ID </label>
                             <input type="email" name="username"  placeholder="Username" value="" class="form-control" required/>
                                 
                               </div>  
                         <div class="form-group">
                             <label>Password</label>
                             <input type="password" name="password" value="" class="form-control" required><br>
                                
<input type="submit"  class="but" name="submit" value="  Sign Up   " ><br><br>

<a href ="index.php"> Login Here </a>						
 </div>
                     </form>
                </div>
        </div>
        </div>
         </body>
</html>
