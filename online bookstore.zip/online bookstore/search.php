<?php

$query = $_GET['query'];
$flag = 0;
if($handle = opendir("Files"))
                {
                    while(($entry = readdir($handle)) !== false)
                    {
                        if($entry != "." && $entry != "..")
                        {  
                            if(strcasecmp($entry, $query . ".txt") == 0)
                            {
                                $flag = 1;
                                
                                header('Location: products.php?prod_id='. $query);
                            }
                        }
                    }
                }
                
                if($flag == 0)
                {
                    header('Location: user.php?notfound');
                }
                       