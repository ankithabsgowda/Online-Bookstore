
<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="User")
{
	header("location:index.php");
}  
?>


<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
    <body>
        <div id="header">
            <h1> BookStream </h1>
             <P>Where Books meet people </P>
          </div> 
        
        <div id="navig">
            <ul>
                <li><a href="user.php">Home</a></li> 
                <li><a href="disc.php">Disclaimer</a></li> 
               
                <li><a href="contact.php">Contact us</a></li> 
                  
            </ul>
        </div> 
        
         <div class="sideright">
            <h2> Recent Uploads </h2>
             <P>Looking for Alaska- John Green</P> 
             <P>Gone Girl -Gillian Flynn</P> 
             <P>Till the Last Breath-Durjoy Datta</P> 
             <P>After all this Time-Nikitha Singh</P> 
        </div> 
        <div class="sideright">
            <h2> Popular Uploads </h2>
             <P>Paper Towns- John Green</P> 
             <P>Rich Dad Poor Dad-Robert T Kiyosaki</P> 
             <P>If its Not Forever-Durjoy Datta</P> 
             <P>Girl in Room 105-Chetan Bhagat</P> 
        </div> 
        
        <div>
            <img class="imageside" src=images/aatm.jpg >
        </div>
        
       
         <div class="main">
              <?php

$target_file = "customer_docs/" . basename($_FILES["userfile"]["name"]);
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

$uploadOK = 1;
if(file_exists($target_file)) {
    echo "<h2>File already exists</h2>";
    $uploadOK = 0;
}


if($uploadOK == 0) {
    echo "<h2>Didnt upload</h2>";
} else {
    if(move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)) {
        echo "<h2>File has been uploaded Succesfully Thank you for contributing! </h2>";
    } else {
        echo "<h2>Error uploading</h2>";
    }
}
?>
            
             </div>
         
         <div id="footer">
             &copy: 2019 Bookstream.com.  All Rights Reserved.
             </div> 
         
        
         
</body>
<script>
    
    function randomImage() {
        var img = document.querySelector('.imageside');
    
    var images = ['aatm.jpg', 'gg2.jpg', 'ltm2.jpg','tgd2.jpg', 'pt2.jpg','taimj.jpg','sao1.jpg'];
    var num = Math.floor(Math.random() * images.length);
    
    var newimg = images[num];
    img.src = 'images/' + newimg;
    }
    
    setInterval(randomImage, 4000);
    
</script>  

</html>

