<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="User")
{
	header("location:index.php");
}  
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
   
   
</head>
    <body>
        <div id="header">
            <h1><center><b> BookStream </h1
                        <h2><center>Where Books meet people </h2><br><a style="color:white;float:right;margin-right:100px;" href="logout.php">Logut(<?php echo $_SESSION['user']; ?>)</a>
             </center><div class="search-box">
                 <form action="search.php">
                 <input class="search-txt" type="text" name="query" placeholder="Type to search">
                 <input type="submit" class="search-btn" >
                 </form>
        </div>
		</div>

           
        
        
        <div id="navig">
            
            <ul>
                <li><a href="user.php">Home</a></li> 
                <li><a href="disc.php">Disclaimer</a></li> 
                 <li><a href="upload.php">Donate Pdf</a></li> 
                 <li><a href="contact.php">Contact Us</a></li> 
            </ul>
			
        </div> 
        
         <div class="sideright">
            <h2> Recent Uploads </h2>
             <P>Looking for Alaska- John Green</P> 
             <P>Gone Girl -Gillian Flynn</P> 
             <P>Till the Last Breath-Durjoy Datta</P> 
             <P>After all this Time-Nikitha Singh</P> 
        </div> 
        <div class="sideright">
            <h2> Popular Uploads </h2>
             <P>Paper Towns- John Green</P> 
             <P>Rich Dad Poor Dad-Robert T Kiyosaki</P> 
             <P>If its Not Forever-Durjoy Datta</P> 
             <P>Girl in Room 105-Chetan Bhagat</P> 
        </div> 
        
        <div>
            <img class="imageside" src=images/pt2.jpg>
        </div>
        
       
         <div class="main">
		 <center><h1>All Books</h1>
		       <div id='singleprod'>
              <?php
         
            
			   if($handle = opendir("Files"))
                {
                    while(($entry = readdir($handle)) !== false)
                    {
                        if($entry != "." && $entry != "..")
                        {   $i=0;
							$rr=0;
							$j=0;
							$pro_des="";
						    $file = fopen("Files/".$entry, 'r');
						    while(!feof($file))
							{
								$line = fgets($file);
								if($i==0)
								{
								list($pro_auth,	$pro_tit) = explode(';', $line);
								}
								else
								{
									$pro_des=$pro_des.$line."\n";
								}
								$i=$i+1;
								
							}
							$file2 = fopen("Rate/".$entry, 'r');
							while(!feof($file2))
							{
								$line = fgets($file2);
								$j=$j+1;
								list($usr,$rate) = explode(';', $line);
								$rr=$rr+(int)$rate;
								
							}
							fclose($file);	
							fclose($file2);	
							if($rr!=0)
							$rr=$rr/($j-1);
							?>
							
							<figure style="float:left;">
							<a href='products.php?prod_id=<?php echo $pro_tit;?>'>
							<img src='images/<?php echo $pro_tit.".jpg";?>' width='140' height='190' title='<?php echo $pro_tit;?>'/> 
						    <figcaption style="color:white;text-align:center;"><?php echo $pro_tit."</a><br>Overall Rate:".sprintf('%0.1f', $rr)."<font size='2px' color='red'>(".($j-1).")</font>";?></figcaption> 
							</figure> 
                                                       
							<?php
						}
                                              
					}
                                        
				}
                                ?>
								
								
								
								
								
              
			 
		      </div></center>
			  </div>
			  
			   
			  
			  
			
			
  
                
				
				
				
				
				
				
				
				
				
			
			 
         
        <div id="footer">
             &copy: 2019 Bookstream.com.  All Rights Reserved.
             </div>
        
        
       
         
       
         
        <?php
        if(isset($_GET['notfound']))
        {       
            echo "<script>alert('Book not found');</script>";
        }
        ?>
		
          
</body>

    
    <script>
    
    function randomImage() {
        var img = document.querySelector('.imageside');
    
    var images = ['aatm.jpg','tbw2.jpg', 'rdpd2.jpg','et2.jpg','gg2.jpg','psm2.jpg','ltm2.jpg','tgd2.jpg', 'pt2.jpg','ta.jpg','sao1.jpg'];
    var num = Math.floor(Math.random() * images.length);
    
    var newimg = images[num];
    img.src = 'images/' + newimg;
    }
    
    setInterval(randomImage, 3000);
    
</script>    
  
</html>