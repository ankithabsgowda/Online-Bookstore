<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="Admin" )
{
	header("location:index.php");
}  
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   

    <body>
        <form method="post" action="view_cust.php" enctype="multipart/form-data">
        <div id="mainA">
         
            <table width="900" allign="center" >
                <tr><center><b><h5><font size="6px" color='purple'><u>Customer Requests</h5></center>
              
            </tr>
            <tr>
                <th> <h3>Customer name</h5></th>
                <th><h3>Email id</h5></th>
               <th><h3>Book name</h5></th>
                <th><h3>Book author</h5></th>
            </tr>
            
            
            <?php
             
$mfile=fopen("custrequest/req.txt","r");
while(!feof($mfile))
{
$line=fgets($mfile);
list($cn,$ce,$cb,$ca) = explode(',', $line);
?>
    <tr>
                <th>     <?php echo $cn; ?>    
                        <th>    <?php echo $ce; ?>  
                                <th>    <?php echo $cb; ?> 
                                        <th>     <?php echo $ca; ?>  
    </tr>
            <?php }
fclose($mfile); ?>

                                                
            </table>
        </div>
        </form>
            </body>
        </html>
        