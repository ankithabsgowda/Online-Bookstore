
<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start(); // Session starts here.
$ck=$_SESSION['logged'];
if($ck!="Admin" && $ck!="User")
{
	header("location:index.php");
}  
?>
<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
         <title>user</title>
        </head>
   
   <link rel="stylesheet" type="text/css" href="stylesheet.css">
   <body>
        <div id="mainA">
		 <center><b><h2><font size="6px" color='Green'>View Books</font></h2></center>
    <table width="1050"  height="600" allign="center ">
     
            <tr><th>
              
             <?php
         
            
			   if($handle = opendir("Files"))
                {
                    while(($entry = readdir($handle)) !== false)
                    {
                        if($entry != "." && $entry != "..")
                        {   
							 $i=0;
							$rr=0;
							$j=0;
							$pro_des="";
						    $file = fopen("Files/".$entry, 'r');
						    while(!feof($file))
							{
								$line = fgets($file);
								if($i==0)
								{
								list($pro_auth,	$pro_tit) = explode(';', $line);
								}
								else
								{
									$pro_des=$pro_des.$line."\n";
								}
								$i=$i+1;
								
							}
							
							
							$file2 = fopen("Rate/".$entry, 'r');
							while(!feof($file2))
							{
								$line = fgets($file2);
								$j=$j+1;
								list($usr,$rate) = explode(';', $line);
								$rr=$rr+(int)$rate;
								
							}
							fclose($file);	
							fclose($file2);	
							if($rr!=0)
							$rr=$rr/($j-1);
							?>
							
							<figure style="float:left;">
							<a href='products.php?prod_id=<?php echo $pro_tit;?>'>
							<img src='images/<?php echo $pro_tit.".jpg";?>' width='140' height='190' title='<?php echo $pro_tit;?>'/> 
						    <figcaption style="color:black;text-align:center;"><?php echo $pro_tit."</a><br>Overall Rate:".sprintf('%0.1f', $rr)."<font size='2px' color='red'>(".($j-1).")</font>";?></figcaption> 
							</figure> 
							<?php
						}
					}
				}
          ?>
                
            </tr>
    </table>
        </div>
		  
    </body>
</html>

